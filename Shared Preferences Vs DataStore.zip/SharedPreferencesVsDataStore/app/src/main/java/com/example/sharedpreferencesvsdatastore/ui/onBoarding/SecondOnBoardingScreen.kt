package com.example.sharedpreferencesvsdatastore.ui.onBoarding

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.viewpager2.widget.ViewPager2
import com.example.sharedpreferencesvsdatastore.R
import com.example.sharedpreferencesvsdatastore.databinding.FragmentSecondOnBoardingScreenBinding


class SecondOnBoardingScreen : Fragment() {
    lateinit var binding : FragmentSecondOnBoardingScreenBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSecondOnBoardingScreenBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.nextButton.setOnClickListener {
            val viewPager2 = requireActivity().findViewById<ViewPager2>(R.id.viewPagerOnBoarding)
            viewPager2.currentItem++

        }
    }

}