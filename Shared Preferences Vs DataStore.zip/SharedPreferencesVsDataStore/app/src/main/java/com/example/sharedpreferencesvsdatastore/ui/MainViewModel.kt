package com.example.sharedpreferencesvsdatastore.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sharedpreferencesvsdatastore.data.Repository
import com.example.sharedpreferencesvsdatastore.utils.Constants.key
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainViewModel (application: Application): AndroidViewModel(application) {
    private val repository = Repository(application)

    fun readOpenHomeScreenWithDataStore():Boolean?
    = runBlocking {  repository.readOpenHomeScreenWithDataStore()[key]}

    fun saveOpenHomeScreenTrueWithDataStore(){
        viewModelScope.launch(Dispatchers.IO) {
        repository.saveOpenHomeScreenTrueWithDataStore()}
    }

    fun readOpenHomeScreenWithSharedPreferences():Boolean
    = runBlocking { repository.readOpenHomeScreenWithSharedPreferences()}

   fun saveOpenHomeScreenTrueWithSharedPreferences() = repository.saveOpenHomeScreenTrueWithSharedPreferences()

}