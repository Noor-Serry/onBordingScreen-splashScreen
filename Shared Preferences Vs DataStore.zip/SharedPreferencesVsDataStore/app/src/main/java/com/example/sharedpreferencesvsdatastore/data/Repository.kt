package com.example.sharedpreferencesvsdatastore.data

import android.content.Context
import android.content.SharedPreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit

import androidx.datastore.preferences.createDataStore
import androidx.preference.PreferenceManager
import com.example.sharedpreferencesvsdatastore.utils.Constants.OPEN_HOME_FRAGMENT

import com.example.sharedpreferencesvsdatastore.utils.Constants.key
import kotlinx.coroutines.flow.first


class Repository (context : Context) {

    private val  dataStore =  context.createDataStore(name = "dataStore")
    var sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

   // new way
    suspend fun  saveOpenHomeScreenTrueWithDataStore(){
        dataStore.edit {
            it.set(key, true)
        }
    }

    suspend fun readOpenHomeScreenWithDataStore()  = dataStore.data.first()

   // old way
    fun  saveOpenHomeScreenTrueWithSharedPreferences(){
            sharedPreferences.edit().putBoolean(OPEN_HOME_FRAGMENT,true).apply()
   }

   fun  readOpenHomeScreenWithSharedPreferences() = sharedPreferences.getBoolean(OPEN_HOME_FRAGMENT,false)



}