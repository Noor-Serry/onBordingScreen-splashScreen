package com.example.sharedpreferencesvsdatastore.ui.onBoarding

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.sharedpreferencesvsdatastore.R
import com.example.sharedpreferencesvsdatastore.data.Repository
import com.example.sharedpreferencesvsdatastore.databinding.FragmentViewPagerOnBoardingBinding
import com.example.sharedpreferencesvsdatastore.utils.Constants
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking


class ViewPagerOnBoarding : Fragment() {
     private lateinit var binding : FragmentViewPagerOnBoardingBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentViewPagerOnBoardingBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setViewPagerAdapter()
    }

    private fun setViewPagerAdapter(){
        val fragments = arrayListOf<Fragment>(FirstOnBoardingScreen(),
        SecondOnBoardingScreen(),ThirdOnBoardingScreen())
        val adapter = ViewPagerAdapter(requireActivity(),fragments)
        binding.viewPagerOnBoarding.adapter = adapter
    }


}