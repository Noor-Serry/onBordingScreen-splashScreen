package com.example.sharedpreferencesvsdatastore.utils

import androidx.datastore.preferences.core.preferencesKey

object Constants {
     val OPEN_HOME_FRAGMENT = "homeFragment"
    val key = preferencesKey<Boolean>(OPEN_HOME_FRAGMENT)
}